from pawpyseed.core.projector import Projector, Wavefunction
import os,sys
import numpy as np
np.set_printoptions(precision=4)

##input parameters
bmin = int(sys.argv[1])
bmax = int(sys.argv[2])
ikpt = 0

T_end = int(sys.argv[3])
T_start = T_end-1 

INIWAV = int(sys.argv[4])
#########################################################################################
##calculate NAC
nbasis=bmax-bmin+1
band_indice=np.arange(bmin-1,bmax)
phacor=np.ones((nbasis,nbasis),dtype=np.complex128)

file_name = "cio.npy" #phase correction factor  
cor1=np.ones(nbasis,dtype=np.complex128)
if (T_start == INIWAV): 
    filepath='%04d' % T_start
    np.save(filepath+'/'+file_name,cor1.view(float))

for i in range(T_start,T_end):

    dir0='%04d' %i
    dir1='%04d' %(i+1)
    wav0 = Wavefunction.from_directory(dir0)
    wav1 = Wavefunction.from_directory(dir1)
#wf = wf.desymmetrized_copy()
#basis = basis.desymmetrized_copy()
    print ('Calculating',dir0)
#pr = Projector(wf, basis, method='aug_real')
#pr = Projector(wf, basis, method='pseudo')
    pr = Projector(wav1, wav0, method='aug_real')

    overlap_list = []

    kpt_len = len(wav1.kpts)
    #print(kpt_len)
    for b_i in band_indice:
        result = pr.single_band_projection(band_num=b_i)
        result = result.reshape((int(len(result)/kpt_len), kpt_len))
        result = result[:, ikpt] 
        overlap_list.append(result[band_indice])

    overlap_list=np.transpose(np.asarray(overlap_list))   #matrix phi(t0)|phi(t1)

    pij=np.array(overlap_list)
    pji=np.conj(np.transpose(overlap_list))
    nac=pij-pji
    
    if ( os.path.isfile(dir0+'/'+file_name)):
        cor1=np.load(dir0+'/'+file_name).view(complex)
    else:
        print ("Phase correction factor not found")
        os._exit(0)

    phase=overlap_list/np.abs(overlap_list)
    cor2=np.multiply(cor1,np.diag(phase))
    phacor1=np.dot(cor1[:,np.newaxis],np.conj(cor2)[np.newaxis,:])
    phacor2=np.dot(cor2[:,np.newaxis],np.conj(cor1)[np.newaxis,:])
    
 
    cor1=cor2
    np.save(dir1+'/'+file_name,cor2.view(float))
    #print ('cor',abs(cor1)) 
    #print('nac',nac,np.abs(nac))
    #print(phacor1)
    #print(phacor2)
    nac_c=np.multiply(pij,phacor1)-np.multiply(pji,phacor2) 
    for i in range(nbasis):
        nac_c[i,i]=0.0+0.0j
    #print('correctednac',nac_c,np.abs(nac_c))

    np.savetxt(dir0 + '/nac2AE_re.txt', nac_c.real.flatten()[np.newaxis, :])
    np.savetxt(dir0 + '/nac2AE_im.txt', nac_c.imag.flatten()[np.newaxis, :])
	
#########################################################################################
##treat NAC to normal format
for i in range(T_start,T_start+1):
    old_im_name = './%04d/nac2AE_im.txt' % i
    old_re_name = './%04d/nac2AE_re.txt' % i
    new_name = './real%04d' % (i+1)
    im = np.loadtxt(old_im_name).reshape(bmax-bmin+1,-1)
    re = np.loadtxt(old_re_name).reshape(bmax-bmin+1,-1)
    if im.shape == re.shape:
        line_num = im.shape[0];row_num = im.shape[1]
        real = np.zeros([line_num,2*row_num])
        for ii in range(row_num):
            real[:,2*ii] = np.array(re[:,ii])
            real[:,2*ii+1] = np.array(im[:,ii])
        np.savetxt(new_name,real,fmt='%.6e')
    else:
        print('ERROR')
os.popen('cp ./%04d/cio.npy ./cio_npy/cio.npy.%04d' % (T_end,T_end))
os.popen('rm -r ./%04d' % T_start)