#!/usr/bin/env python
# -*- coding: utf-8 -*-   
'''
	Hefei_run with phase correction
'''
############################################################
import os,sys
import numpy as np
import multiprocessing
from vaspwfc import vaspwfc

############################################################

def orthogon(cic):
    
    S = np.dot(cic.conj(),cic.T)
    
    #print "S",S

    Dsqrt= np.zeros_like(S, dtype=np.complex)
    T = np.zeros_like(S, dtype=np.complex)
    cio = np.zeros_like(cic, dtype=np.complex)
    
    D,V=np.linalg.eig(S)
    for ii in range(np.size(S,0)):
        Dsqrt[ii,ii]=1/np.sqrt(D[ii])
    #print "Dsqrt",Dsqrt
    T=np.dot(np.dot(V.conj(),Dsqrt.conj()),V.T)
    
    cio = np.dot(T,cic)
    #print "cio",cio.shape
   # for ii in range(np.size(S,0)):
   #     for jj in range(np.size(S,0)):
   #         cio[ii,:]+=T[ii,jj]*cic[jj,:]
    
    return cio
def nac_from_vaspwfc(waveA, waveB, wave0, gamma=True,
                     bmin=None, bmax=None, omin=None, omax=None,
                     dt=1.0, ikpt=1, ispin=1):
    '''
    Calculate Nonadiabatic Couplings (NAC) from two WAVECARs
    <psi_i(t)| d/dt |(psi_j(t))> ~=~
                                    (<psi_i(t)|psi_j(t+dt)> -
                                     <psi_i(t+dt)|psi_j(t)>) / (2dt)
    inputs:
        waveA:  path of WAVECAR A
        waveB:  path of WAVECAR B
        gamma:  gamma version wavecar
        dt:     ionic time step, in [fs]          
        ikpt:   k-point index, starting from 1 to NKPTS
        ispin:  spin index, 1 or 2

    !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    !!!! Note, this method is much slower than fortran code. !!!!
    !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    '''

    phi_i = vaspwfc(waveA)      # wavecar at t
    phi_j = vaspwfc(waveB)      # wavecar at t + dt
    phi_0 = vaspwfc(wave0)

    print('Calculating NACs between <%s> and <%s>' % (waveA, waveB))

    assert phi_i._nbands == phi_j._nbands, '#bands not match!'
    assert phi_i._nplws[ikpt-1] == phi_j._nplws[ikpt-1], '#nplws not match!'

    bmin = 1 if bmin is None else bmin
    bmax = phi_i._nbands if bmax is None else bmax
    nbasis = bmax - bmin + 1
    obasis = omax - omin + 1    # Orthogonalized basis

    nacType = np.float if gamma else np.complex
    nacs = np.zeros((nbasis, nbasis), dtype=nacType)
    pij = np.zeros((nbasis, nbasis), dtype=np.complex)
    pji = np.zeros((nbasis, nbasis), dtype=np.complex)
    
    
    

    ci_t   = phi_i.readBandCoeff(ispin, ikpt, omax, norm=True)
    #ci_t = np.append(ci_t,ci_t[1:]*1j)
    cic_0 = np.zeros([obasis] + list(ci_t.shape),dtype=np.complex)
    cic_t = np.zeros([obasis] + list(ci_t.shape),dtype=np.complex)
    cic_tdt = np.zeros([obasis] + list(ci_t.shape),dtype=np.complex)
           
    cio_t = np.zeros([obasis] + list(ci_t.shape),dtype=np.complex)
    cio_tdt = np.zeros([obasis] + list(ci_t.shape),dtype=np.complex)
    print(cic_t.shape)
    from time import time
    t1 = time()
    
    file_path = "cio.npy"    #Orthogonalized Wavefunction for time=0
 
    if ( os.path.isfile(file_path)):
        cio_0 = np.load(file_path).view(complex)
        if( np.size(cio_0,0) != np.size(cic_0,0)):
            print("# of Bands from cio.txt not equal")

    else:
        print("Orthogonalized Wavefunction not found")
        for ii in range(obasis):
            ib1 = ii + omin
            cic_0[ii,:]   = phi_0.readBandCoeff(ispin, ikpt, ib1, norm=True)
        #cio_0 = orthogon(cic_0)
        cio_0 = cic_0
        np.save(file_path,cio_0.view(float))



    for ii in range(obasis):
            ib1 = ii + omin
            cic_t[ii,:]   = phi_i.readBandCoeff(ispin, ikpt, ib1, norm=True)
            cic_tdt[ii,:]   = phi_j.readBandCoeff(ispin, ikpt, ib1, norm=True)
    #print "test",cic_t.shape        
    #cio_t = orthogon(cic_t)
    #cio_tdt = orthogon(cic_tdt)
    #print "cio_t",cio_t.shape,np.dot(cio_t.conj()[1,:],cio_t[2,:]),np.dot(cio_t.conj()[2,:],cio_t[2,:]),np.dot(cio_t.conj()[1,:],cio_t[3,:])
    cio_t =cic_t
    cio_tdt =cic_tdt   
    
    
    np.savetxt('ci1.txt',np.dot(cio_tdt.conj(),cio_tdt.T))
    np.savetxt('ci2.txt',np.dot(cio_t.conj(),cio_t.T))
    



    cor1 =cio_0.conj()*cio_t
    cor1 =np.sum(cor1,axis=1)
    #print cor1.shape
    cc1= cor1/abs(cor1)
    #print "cor1",abs(cor1)
    np.savetxt('cc1.txt',cc1) 

    cor2 =cio_0.conj()*cio_tdt
    cor2 =np.sum(cor2,axis=1)
    #print cor2.shape,cor2
    cc2= cor2/abs(cor2)
    
    np.savetxt('cc2.txt',cc2) 
    #cic_t*=cor1.conj()
    #cic_tdt*=cor2.conj()
    
          
    for ii in range(nbasis):
        for jj in range(ii):
       # for jj in range(nbasis):

            ibi = ii + bmin - omin 
            ibj = jj + bmin - omin  

            # None Phase Correction           

            #pij[ii,jj] = np.sum(cio_t[ibi,:].conj()*cio_tdt[ibj,:])
            #pji[ii,jj] = np.sum(cio_tdt[ibi,:].conj()*cio_t[ibj,:])
            
            #Phase Correction
            
            pij[ii,jj] = np.sum(cio_t[ibi,:].conj()*cio_tdt[ibj,:])*cc1[ibi]*cc2[ibj].conj()
            pji[ii,jj] = np.sum(cio_tdt[ibi,:].conj()*cio_t[ibj,:])*cc2[ibi]*cc1[ibj].conj()
            #pij[ii,jj] = np.sum(cio_t[ibi,:].conj()*cio_tdt[ibj,:])*cc1[ibi]*cc2[ibj].conj()-np.sum(cio_t[ibi,:].conj()*cio_t[ibj,:])*cc1[ibi]*cc1[ibj].conj()
            #pji[ii,jj] = np.sum(cio_tdt[ibi,:].conj()*cio_t[ibj,:])*cc2[ibi]*cc1[ibj].conj()-np.sum(cio_tdt[ibi,:].conj()*cio_tdt[ibj,:])*cc2[ibi]*cc2[ibj].conj()
           
            #qij[ii,jj]= np.sum()
            #qji[ii,jj]
            
            tmp = pij[ii,jj]-pji[ii,jj]
            #tmp = np.sum(cic_t[ibi,:].conj() * cic_tdt[ibj,:])*cor1[ibi]*cor2.conj[ibj] - np.sum(cic_tdt[ibi,:].conj() * cic_tdt[ibj,:])
            
            nacs[ii,jj] = tmp.real if gamma else tmp
            if gamma:
                nacs[jj,ii] = -nacs[ii,jj]
            else:
                nacs[jj,ii] = -np.conj(nacs[ii,jj])

    t2 = time()
    print('1. Elapsed Time: %.4f [s]' % (t2 - t1))
  # EnT = (phi_i._bands[ispin-1,ikpt-1,:] + phi_j._bands[ispin-1,ikpt-1,:]) / 2.
    EnT = phi_i._bands[ispin-1,ikpt-1,bmin-1:bmax]
    
    # close the wavecar
    phi_i._wfc.close()
    phi_j._wfc.close()

    # return EnT, nacs / (2 * dt)
    return EnT, nacs,pij,pji


def parallel_nac_calc(runDirs, nproc=None, gamma=False,
                      bmin=None, bmax=None,omin=None, omax=None,
                      ikpt=1, ispin=1, dt=1.0):
    '''
    Parallel calculation of NACs using python multiprocessing package.
    '''
    import multiprocessing
    
    nproc = multiprocessing.cpu_count() if nproc is None else nproc
    pool = multiprocessing.Pool(processes=nproc)
    P=[0,0]
    results = []
    
    w0=runDirs[0]
    print(w0)
    for w1, w2 in zip(runDirs[:-1], runDirs[1:]):
        res = pool.apply_async(nac_from_vaspwfc, (w1, w2, w0, gamma, bmin, bmax, omin, omax, dt, ikpt, ispin,))
        results.append(res)

    for ii in range(len(runDirs)-1):
        et, nc , pij, pji= results[ii].get()

        prefix = os.path.dirname(runDirs[ii])
        np.savetxt(prefix + '/eig.txt', et[np.newaxis, :])
        np.savetxt(prefix + '/nac2_re.txt', nc.real.flatten()[np.newaxis, :])
        np.savetxt(prefix + '/nac2_im.txt', nc.imag.flatten()[np.newaxis, :])
        P[0]=[pij[-1,-2],pji[-1,-2]]
        P[1]=[pij[-2,-1],pji[-2,-1]]
        np.savetxt(prefix + '/pij2.txt', P)


############################################################
# a test
############################################################

if __name__ == '__main__':

	##input parameters
	bmin = int(sys.argv[1])
	bmax = int(sys.argv[2])
	T_end   = int(sys.argv[3])
	T_start = T_end-1

	##calculate NAC
	WaveCars = ['./%04d/WAVECAR' % (ii + 1) for ii in range(T_start-1, T_end)]
	parallel_nac_calc(WaveCars,nproc=1,gamma=False, bmin=bmin, bmax=bmax,omin=bmin,omax=bmax)
	
	os.popen('rm cc* ci*')
	
	##treat NAC to normal format
	for i in range(T_start,T_start+1):
		old_im_name = './%04d/nac2_im.txt' % i
		old_re_name = './%04d/nac2_re.txt' % i
		new_name = './real%04d' % (i+1)
		im = np.loadtxt(old_im_name).reshape(bmax-bmin+1,-1)
		re = np.loadtxt(old_re_name).reshape(bmax-bmin+1,-1)
		if im.shape == re.shape:
			line_num = im.shape[0];row_num = im.shape[1]
			real = np.zeros([line_num,2*row_num])
			for ii in range(row_num):
				real[:,2*ii] = np.array(re[:,ii])
				real[:,2*ii+1] = np.array(im[:,ii])
			np.savetxt(new_name,real,fmt='%.6e')
		else:
			print('ERROR')
     

