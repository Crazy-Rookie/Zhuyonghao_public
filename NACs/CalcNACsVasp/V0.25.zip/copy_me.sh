VASPCOMMAND='vasp_std'

#############################################################
## NOTE: 3_all_elec*0.33=eV; 2_phase_correc*0.33=eV; 1_normal(eV)

## Set Up Parameters
MINB=13     # lowest energy orbital from which electrons can excite
MAXB=14     # highest energy orbital to which electrons can go 
MINT=1      # starting step
StartTime=1 # generally =MINIT
MAXT=5      # ending step
TMSTP=1     # time step
#############################################################

## mkdir cio_npy in ./run_nac/3_all_elec
if [ ! -d ./run_nac/3_all_elec/cio_npy ]; then mkdir ./run_nac/3_all_elec/cio_npy; fi
## mkdir ipr and overlap in ./Ipr_Overlap
if [ ! -d ./Ipr_Overlap/ipr ]; then mkdir ./Ipr_Overlap/ipr; fi
if [ ! -d ./Ipr_Overlap/overlap ]; then mkdir ./Ipr_Overlap/overlap; fi
## mkdir procar_npy in ./procar
if [ ! -d ./procar/procar_npy ]; then mkdir ./procar/procar_npy; fi
#############################################################

printf "\n======= INITIAL PARAMETERS (MINBAND MAXBAND MINTIME MAXTIME TIMESTEP) ========\n" 
printf "           %10d%10d%10d%10d%10d\n\n" $MINB $MAXB $MINT $MAXT $TMSTP

## FIRST RUN
# StartTime = MINT ?
if [ "$StartTime" -eq "$MINT" ];then 
	SUFX=$( printf "%04d" "$MINT" ) &&
	cd ./run_scf/$SUFX &&
	printf "Running VASP at t = $MINT fs and getting initial set of good orbitals\n" &&
	$VASPCOMMAND &&
	rm -f CHG CHGCAR DOSCAR EIGENVAL IBZKPT PCDAT REPORT XDATCAR &&
	printf "\n=======================================\n" 
	cd ../../
	(( StartTime++ ))
fi
#############################################################

## START CALCULATING THE COUPLiNGS ALONG THE TRAJECTORY
for time in `seq $StartTime $MAXT`
do
# run vasp
	# define prefix
	SUFX_1=$( printf "%04d" "$time" ) &&
	SUFX_tmp=$((time-1))
	SUFX_0=$( printf "%04d" "$SUFX_tmp" ) &&
	# check and copy WAVECAR
	# ./scf_run/$SUFX_0/WAVECAR
	if [ ! -f ./scf_run/$SUFX_0/WAVECAR ]; then 
		printf "\n--Error! There was no WAVECAR in $SUFX_0! Exiting....--\n"
		exit
	fi
	# ./scf_run/$SUFX_1/WAVECAR
	if [ ! -f ./scf_run/$SUFX_1/WAVECAR ]; then 
		cp ./scf_run/$SUFX_0/WAVECAR ./scf_run/$SUFX_1
	fi
	# run vasp
	cd ./scf_run/$SUFX_1 &&
	printf "Running vasp at t = $time fs \n" &&
	$VASPCOMMAND &&
	rm -f CHG CHGCAR DOSCAR EIGENVAL IBZKPT PCDAT REPORT XDATCAR &&
	printf "\n=======================================\n" 
	cd ../../
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# nac: 1_normal
	cd ./run_nac/1_normal &&
	ln -s ./scf_run/$SUFX_0/WAVECAR  WAVECAROLD &&
	ln -s ./scf_run/$SUFX_1/WAVECAR  WAVECARNEW &&
	./ovlap_NORM_OS $MINB $MAXB $TMSTP $SUFX &&
	printf "1_normal: Getting NAC at t = $time fs \n" &&
	cat energy_by_band >> energy &&
	rm WAVECARNEW WAVECAROLD &&
	cd ../../ &&
	printf "\n=======================================\n" 
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# nac: 2_phase_correc
	cd ./run_nac/2_phase_correc/ &&
	if [ ! -d ./run_nac/2_phase_correc/$SUFX_0 ]; then 
		mkdir ./run_nac/2_phase_correc/$SUFX_0 &&
		ln -s ./scf_run/$SUFX_0/WAVECAR ./$SUFX_0
	fi
	if [ ! -d ./run_nac/2_phase_correc/$SUFX_1 ]; then 
		mkdir ./run_nac/2_phase_correc/$SUFX_1 &&
		ln -s ./scf_run/$SUFX_1/WAVECAR ./$SUFX_1
	fi
	printf "2_phase_correc: Getting NAC at t = $time fs \n" &&
	python nac.py $MINB $MAXB $time &&
	rm -r $SUFX_0 &&
	cd ../../ &&
	printf "\n=======================================\n" 
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# nac: 3_all_elec
	cd ./run_nac/3_all_elec/ &&
	if [ ! -d ./run_nac/3_all_elec/$SUFX_0 ]; then 
		mkdir ./run_nac/3_all_elec/$SUFX_0 &&
		ln -s ./scf_run/$SUFX_0/WAVECAR ./$SUFX_0 &&
		ln -s ./scf_run/$SUFX_0/POTCAR ./$SUFX_0 &&
		ln -s ./scf_run/$SUFX_0/vasprun.xml ./$SUFX_0 &&
		ln -s ./scf_run/$SUFX_0/CONTCAR ./$SUFX_0
	fi
	if [ ! -d ./run_nac/3_all_elec/$SUFX_1 ]; then 
		mkdir ./run_nac/3_all_elec/$SUFX_1 &&
		ln -s ./scf_run/$SUFX_1/WAVECAR ./$SUFX_1 &&
		ln -s ./scf_run/$SUFX_1/POTCAR ./$SUFX_1 &&
		ln -s ./scf_run/$SUFX_1/vasprun.xml ./$SUFX_1 &&
		ln -s ./scf_run/$SUFX_1/CONTCAR ./$SUFX_1
	fi
	printf "3_all_elec: Getting NAC at t = $time fs \n" &&
	python paw2.py $MINB $MAXB $time $((MINT++))
	rm -r $SUFX_0 &&
	cd ../../ &&
	printf "\n=======================================\n" 
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# procar: save porcar.npy
	if [ -f ./scf_run/$SUFX_1/PROCAR ]; then
		cd ./procar/ &&
		ln -s ./scf_run/$SUFX_1/PROCAR &&
		printf "read procar: Getting procar.npy at t = $time fs \n" &&
		python ReadProcar.py &&
		mv band_energy.npy ./procar_npy/band_energy.$SUFX_1.npy &&
		mv procay.npy ./procar_npy/procar.$SUFX_1.npy &&
		rm PROCAR &&
		cd ../
	fi 
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# ipr and overlap: ipr_overlap
	if [ -f ./scf_run/$SUFX_1/WAVECAR ]; then
		cd ./Ipr_Overlap/ &&
		ln -s ./scf_run/$SUFX_1/WAVECAR &&
		printf "calc ipr: Getting IPR at t = $time fs \n" &&
		python Ipr_Overlap.py $MINB $MAXB &&
		mv ipr.dat ./ipr/ipr.$SUFX_1.dat &&
		mv overlap.dat ./overlap/overlap.$SUFX_1.dat &&
		cd .. &&
		printf "\n=======================================\n" 
	fi
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

done

(( MINT-- ))