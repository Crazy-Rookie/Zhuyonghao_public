#! /usr/bin/python3
# -*- coding: utf-8 -*-
#  .--,       .--,
# ( (  \.---./  ) )
#  '.__/o   o\__.'
#     {=  ^  =}
#      >  -  <
#     /  Zhu  \
#    //  Yong \\
#   //|  Hao  |\\
#   "'\       /'"_.-~^`'-.
#      \  _  /--'         `
#    ___)( )(___
#   (((__) (__)))  
'''
   1. NAC calc. or IPR, TdmOS, overlap, radiatime calc.
   2. input fiels: WAVECAR (vasp_std)
   3. band_ini and band_fin: start 1, including
   4. author: yonghao_zhu@163.com
   5. github: https://github.com/yonghao-zhu
   6. Organizations: https://github.com/Crazy-Rookie
'''
###########################################################################
import numpy as np
import sys,os
np.seterr(divide='ignore',invalid='ignore')
np.warnings.filterwarnings('ignore', category=np.VisibleDeprecationWarning)
##########################################################################

phy_params = {}
phy_params['TorF']       = True # True or False
phy_params['ispin']      = 1 # start 1, 1 or 2
phy_params['ikpt']       = 1 # start 1, 
phy_params['wfc']        = 'WAVECAR'
phy_params['IPR']        = True  # True or False, ipr.dat
phy_params['overlap']    = True  # overlap.dat
phy_params['TdmOS']      = False # tdmos.dat
phy_params['OS']         = False # oscillator strength
phy_params['band_ini']   = int(sys.argv[1])
phy_params['band_fin']   = int(sys.argv[2])
##########################################################################

## Basic Knowledge. This function is useless in calculating NAC and other physical parameters.
def BackGrouVasp(VASP_WAVECAR_format='http://www.andrew.cmu.edu/user/feenstra/wavetrans/'):
   VASP_WAVECAR_format=''' 
   http://www.andrew.cmu.edu/user/feenstra/wavetrans/
   |
   Record-length #spin components RTAG(a value specifying the precision)
   #k-points #bands ENCUT(maximum energy for plane waves)
   LatVec-A
   LatVec-B
   LatVec-C
   Loop over spin
      Loop over k-points
         #plane waves, k vector
         Loop over bands
            band energy, band occupation
         End loop over bands
         Loop over bands
            Loop over plane waves
               Plane-wave coefficient
            End loop over plane waves
         End loop over bands
      End loop over k-points
   End loop over spin
   |
   '''
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

## Read WAVEfunction. The function is to read WAVECAR (vasp format).
## return bands, coefficient, spin_kpoints_bands_Ene, E_fermi,gvec
def ReadVaspWfc(file_wfc):

   # read file_wfc
   '''
      NOTE: On the first line of the WAVECAR file, 
            a value of RTAG of 45200 specifies that complex*8 binary format is used for the coefficients,
            whereas a value of 45210 specifies complex*16 format.
   '''
   wfc_binary = open(file_wfc, 'rb')
   
   wfc_binary.seek(0)

   # spin
   record, spin, rtag = np.array(np.fromfile(wfc_binary,dtype=np.float,count=3),dtype=int)
   #test#print(np.fromfile(wfc_binary, dtype=np.float).shape, record, spin, rtag)

   # E-fermi
   wfc_binary.seek(record+12*8)
   E_fermi = np.fromfile(wfc_binary, dtype=np.float, count=1)
   #test#print(E_fermi)
   
   # kpoints, bands, encut, lattice in real space, lattice in reciprocal space
   wfc_binary.seek(record)
   line_temp = np.fromfile(wfc_binary, dtype=np.float, count=12)
   kpoints, bands, encut = int(line_temp[0]), int(line_temp[1]), int(line_temp[2])
   latt_real_space = line_temp[3:].reshape(3, 3)
   latt_volume = np.linalg.det(latt_real_space)
   latt_recip_space = np.linalg.inv(latt_real_space).T
   #test#print('kpoints=', kpoints, '; nbands=', bands, '; encut=', encut)
   #test#print(latt_real_space, '\n', latt_volume, '\n', latt_recip_space)

   # kpoints matrix and spin-kpoints-bands energy and occupation matrix
   kpoints_PlaneWaves = np.zeros((spin ,kpoints), dtype=int)
   kpoints_kVector = np.zeros((spin ,kpoints, 3), dtype=float)
   spin_kpoints_bands_Ene = np.zeros((spin, kpoints, bands), dtype=float)
   spin_kpoints_bands_Occup = np.zeros((spin, kpoints, bands), dtype=float)
   Coeffi = []

   for ispin in range(spin):
      for ikpt in range(kpoints):

         num = ispin*( kpoints*(bands+1) ) + ( 2 + ikpt*(bands+1) ) 
         wfc_binary.seek( num*record )

         line_temp = np.fromfile(wfc_binary, dtype=np.float, count=4+3*bands)

         kpoints_PlaneWaves[ispin, ikpt] = int(line_temp[0])
         kpoints_kVector[ispin, ikpt] = line_temp[1:4]
         line_temp = line_temp[4:].reshape((-1,3))
         spin_kpoints_bands_Ene[ispin, ikpt, :] = line_temp[:,0]
         spin_kpoints_bands_Occup[ispin, ikpt, :] = line_temp[:,2]
         #test#print(kpoints_PlaneWaves)

         for iband in range(bands):

            num = ispin*( kpoints*(bands+1) ) + ( 2 + ikpt*(bands+1) ) + iband
            wfc_binary.seek( num*record )
            
            line_temp = np.fromfile(wfc_binary, dtype=np.complex64, count=kpoints_PlaneWaves[ispin, ikpt])

            coefficient_ = np.asarray(line_temp, dtype=np.complex128)
            norm = np.linalg.norm(coefficient_)
            coefficient = coefficient_/norm
            #test#print(coefficient.shape)
            Coeffi.append(coefficient)

   if kpoints == 1:
      Coeffi = np.array( Coeffi ).reshape([spin, kpoints, bands, -1])
   else:
      Coeffi = np.array( Coeffi ).reshape([spin, kpoints, bands])
   #test#print(Coeffi.shape)

   # FFT grid, 1Ry=13.605826eV, 1a.u.=0.529177249Angstrom (bohr)
   # https://www.unitconverters.net/length/a-u-of-length-to-angstrom.htm
   # np.linalg.norm()--The second norm of the vector is the vector length in the traditional sense
   real_space_norm = np.linalg.norm(latt_real_space, axis=1)
   fft_grid_temp = np.ceil(np.sqrt(encut/13.605826)/(2*np.pi/(real_space_norm/0.529177249)))
   fft_grid = np.array(2*fft_grid_temp+1, dtype=int)
   #test#print(real_space_norm,'\n',fft_grid)

   # Transition dipole moment
   # https://en.wikipedia.org/wiki/Transition_dipole_moment
   fx = [i if i < fft_grid[0]/2+1 else i-fft_grid[0]
      for i in range(fft_grid[0])]
   
   fy = [j if j < fft_grid[1]/2+1 else j-fft_grid[1]
      for j in range(fft_grid[1])]
   
   fz = [k if k < fft_grid[2]/2+1 else k-fft_grid[2]
      for k in range(fft_grid[2])]
   #test#print(fx);print(fy);print(fz)

   kgrid = np.array([(fx[i], fy[j], fz[k])
      for k in range(fft_grid[2])
      for j in range(fft_grid[1])
      for i in range(fft_grid[0])], dtype=float)
   #test#print(kgrid.shape)

   for ikpt in range(kpoints):
      KENERGY = 13.605693009*0.529177249*0.529177249 * np.linalg.norm(np.dot(
         kgrid + kpoints_kVector[0, ikpt][np.newaxis,:],2*np.pi*latt_recip_space
         ),axis=1)**2
      Gvec = np.asarray(kgrid[np.where(KENERGY<encut)[0]],dtype=int)
      gvec = np.dot(Gvec,latt_recip_space*2*np.pi) 
      #test#print(gvec.shape)

   wfc_binary.close()

   return bands, Coeffi, spin_kpoints_bands_Ene, E_fermi, gvec
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

## This function can calculate transition dipole moment, oscillator strength,
## IPR, radiative lifetime, and so on from WAVECAR file.
def Osci_IPR_RadiaTime(params):

   '''
   transition dipole moment & oscillator strength
   https://en.wikipedia.org/wiki/Transition_dipole_moment
   https://aip.scitation.org/doi/10.1063/1.4793277
   http://bbs.keinsci.com/thread-1642-1-1.html
   https://shodhganga.inflibnet.ac.in/bitstream/10603/93457/12/12_chapter4.pdf
   http://www.momap.net.cn/docs-en/appendix.html
   http://web.mit.edu/multiwfn_v3.4/Manual_3.4.pdf
   https://chemistry.stackexchange.com/questions/31257/why-acetone-does-not-behave-like-its-computational-values
   https://pdfs.semanticscholar.org/4c2d/00afdaadc970938ddb8b7cc634576fe0a6b5.pdf
   '''

   # analyze params
   band_ini = params['band_ini']
   band_fin = params['band_fin']
   TdmOs    = params['TdmOS']
   IPR      = params['IPR']
   overlap  = params['overlap']
   OS       = params['OS']
   file_wfc = params['wfc']
   ispin    = params['ispin'] - 1 # start 0
   ikpt     = params['ikpt'] - 1 # start 0

   # read wfn
   print('Reading %s...' %file_wfc)
   bands, Coeffi, spin_kpoints_bands_Ene, E_fermi, gvec = ReadVaspWfc(file_wfc=file_wfc)

   band_energy = spin_kpoints_bands_Ene
   kpoints = band_energy.shape[1]
   #test#print(band_energy.shape)

   # tdm, os and radia_time calculation
   ks_i = band_ini  # [ispin, ik_points, ibands]
   ks_j = band_fin

   Tdm       = np.zeros( [ks_j-ks_i+1, ks_j-ks_i+1] )
   Os        = np.zeros( [ks_j-ks_i+1, ks_j-ks_i+1] )
   Ipr       = np.zeros( [ks_j-ks_i+1] )
   ovlap     = np.zeros( [ks_j-ks_i+1, ks_j-ks_i+1], dtype=complex )

   print('Calculating...')

   for iband in range(ks_i, ks_j+1):

      phi_ = Coeffi[ispin, ikpt, iband]
      #test#print(phi_.shape)

      phi_abs = np.abs(phi_)
      ipr = np.sum( phi_abs**4 ) / ( np.sum(phi_abs**2)**2 )
      Ipr[iband-band_ini] = ipr

      for jband in range(iband+1, ks_j+1):  
         dE = band_energy[ispin, ikpt, jband-1] - band_energy[ispin, ikpt, iband-1]
         phj_ = Coeffi[ispin, ikpt, jband]
         #test#print(phj_.shape)

         overlap_ = np.sum(phi_.conjugate()*phj_)
         ovlap[iband-band_ini, jband-band_ini] = overlap_
         #test#print(overlap)

         # http://wild.life.nctu.edu.tw/~jsyu/compchem/g09/g09ur/k_constants.htm
         # 0.529177249 angstrom = 1 a.u. of length, 1 bohr a.u. = 0.529177249 A
         # 1 Bohr-electron (electric dipole moment au) = 2.541746 Debye
         # 1 Ry=13.605693009 eV
         # tdm = 1j / (dE / (2 * 13.605693009)) * tdm * 0.529177249 * 2.541746
         tdm_0 = np.sum( (phi_.conjugate()*phj_)[:, np.newaxis] * gvec[ikpt], axis=0 )
         # Debye
         tdm_1 = 1j / (dE / (2 * 13.605693009)) * tdm_0 * 0.529177249  # eV
         tdm = np.sqrt(np.sum(np.abs(tdm_1)**2))
         Tdm[iband-band_ini, jband-band_ini] = tdm
         
         # oscillator strength
         os = 2/3*dE*tdm/27.2114  # 1 hartree = 27.2114 eV
         Os[iband-band_ini, jband-band_ini] = os
         
         # radiative lifetime
         # C = 2.193297931090221e9 / (2.01**2)  # perovskite example
         #radia_time = 1/(C*(dE**2)*os)*1e12  # ps
         #Radiatime[iband-band_ini, jband-band_ini] = radia_time

   # save files
   if overlap:
      np.savetxt('overlap.dat', ovlap, fmt='%06e')
   if IPR:
      np.savetxt('ipr.dat', Ipr, fmt='%06e')
   if TdmOs:
      np.savetxt('tdmos.dat', Tdm, fmt='%06e')
   if OS:
      np.savetxt('OS.dat', Os, fmt='%06e')

########################################################################

def main(phy_params):
   
   if phy_params['TorF']:

      # check wfc file
      if os.path.isfile(phy_params['wfc']):
         print('Running Osci_IPR_RadiaTime() function...')
         Osci_IPR_RadiaTime(params=phy_params)
      else:
         print('No %s! Exiting...' %phy_params['wfc'])
         exit()

if __name__ == '__main__':
   main(phy_params=phy_params)

