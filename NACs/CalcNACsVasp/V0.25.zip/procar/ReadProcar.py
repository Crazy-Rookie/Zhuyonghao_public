#! /usr/bin/python3
# -*- conding=UTF-8 -*-

#  .--,       .--,
# ( (  \.---./  ) )
#  '.__/o   o\__.'
#     {=  ^  =}
#      >  -  <
#     /  Zhu  \
#    //  Yong \\
#   //|  Hao  |\\
#   "'\       /'"_.-~^`'-.
#      \  _  /--'         `
#    ___)( )(___
#   (((__) (__)))  


'''
	1. read PROCAR to save procar.npy and band_energy.npy
	2. only support: procar with single kpoint
	3. author: yonghao_zhu@163.com
	4. date: 2021-06-28
'''

import numpy as np
import os
import linecache

params = {}
params['procar_file']     = 'PROCAR'
params['band_energy_npy'] = 'band_energy.npy'
params['procar_npy']      = 'procar.npy'
params['nkpt']            = 1 # not change
params['nspin']           = 1 # 1 or 2
########################################################################################################

def ReadProcar(params):

	'''
		procar.shape      = [nspin, nkpt, nbands, nions]
		band_energy.shape = [nspin, nkpt, nbands]
		procar_sum_iatoms.shape = [nspin, nkpt, nbands]
	'''

	# check file
	if not os.path.isfile(params['procar_file']):
		print('No %s! Exiting...' % params['procar_file'])
		exit()

	#seconde_line: ['#', 'of', 'k-points:', '133', '#', 'of', 'bands:', '48', '#', 'of', 'ions:', '6']
	seconde_line = linecache.getline(params['procar_file'], 2).split()
	nkpt = int(seconde_line[3])
	nbands = int(seconde_line[7])
	nions = int(seconde_line[11])
	nspin = params['nspin']

	print('-------------')
	print('nspin  =', params['nspin'])
	print('nkpt   =', nkpt)
	print('nbands =', nbands)
	print('nions  =', nions)
	print('-------------')

	# read procar
	if not os.path.isfile(params['procar_npy']):
		print('Saving %s!' %params['procar_npy'])

		# read PROCAR: band_energy
		with open(params['procar_file'], 'r') as f:
			band_energy = []
			for i in f:
				if 'energy' in i:
					band_energy.append(float(i.split()[4]))

			band_energy = np.array(band_energy).reshape(nspin, nkpt, nbands)
			#test#print('band_energy.shape=', band_energy.shape)

			np.save(params['band_energy_npy'],band_energy)

		#read PROCAR: projection band
		comments = ['#','band',' k-point','tot','\n','PROCAR','ion',' \n']
		procar = np.loadtxt(params['procar_file'] ,comments=comments,dtype=str,delimiter='\n')
		procar = np.array([float(i.split()[-1]) for i in procar]).reshape(nspin, nkpt, nbands, nions)
		#test#print('procar.shape=', procar.shape)

		np.save(params['procar_npy'],procar)

def main(params):
	 
		ReadProcar(params=params)

if __name__ == '__main__':
	main(params=params)

